import "./App.css";
import Header from "./components/Header";
import InputArea from "./components/InputArea";
import Output from "./components/OutputArea";
import { useState } from "react";
import { calculateInvestmentResults } from "../src/assets/CalculateFunction.js";

function App() {
  const [userInput, setUserInput] = useState({
    monthlyInvestment: 0,
    expectedReturn: 0,
    duration: 0,
  });

  const validation = userInput.duration >= 1;

  const [totalValue, setTotalValue] = useState({
    totalInvestment: 0,
    expectedReturn: 0,
    totalEarnings: 0,
  });

  function handleFinalValue(value) {
    setTotalValue(value);
  }

  function handleChange(inputIdentifier, newValue) {
    setUserInput((preUserInput) => {
      return {
        ...preUserInput,
        [inputIdentifier]: +newValue,
      };
    });
  }

  // const result = calculateInvestmentResults();
  // console.log(result);

  return (
    <center>
      <div id="main-body">
        <Header></Header>
        <InputArea
          onchange={handleChange}
          userData={userInput}
          userTotalValue={calculateInvestmentResults}
          result={handleFinalValue}
        ></InputArea>
        {validation ? (
          totalValue.totalInvestment > 0 && (
            <Output userData={totalValue}></Output>
          )
        ) : (
          <p>Enter Valid Data </p>
        )}
      </div>
    </center>
  );
}

export default App;
