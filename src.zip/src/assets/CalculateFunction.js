
// export function calculateInvestmentResults({
//   monthlyInvestment,
//   expectedReturn,
//   duration,
// }) {
//   const annualData = [];
//   let investmentValue = 0;

//   for (let year = 0; year < duration; year++) {
//     for (let month = 0; month < 12; month++) {
//       const monthlyInterestEarned = investmentValue * ((expectedReturn / 100) / 12);
//       investmentValue += monthlyInterestEarned + monthlyInvestment;

//       annualData.push({
//         year: year + 1,
//         month: month + 1,
//         interest: monthlyInterestEarned,
//         valueEndOfMonth: investmentValue,
//         monthlyInvestment: monthlyInvestment,
//       });
//     }
//   }

//   return annualData;
// }

export function calculateInvestmentResults({
  monthlyInvestment,
  expectedReturn,
  duration,
}) {
  const annualData = [];
  let investmentValue = 0;
  let totalInvestment = 0;

  for (let year = 0; year < duration; year++) {
    for (let month = 0; month < 12; month++) {
      const monthlyInterestEarned = investmentValue * ((expectedReturn / 100) / 12);
      investmentValue += monthlyInterestEarned + monthlyInvestment;
      totalInvestment += monthlyInvestment;

      annualData.push({
        year: year + 1,
        month: month + 1,
        interest: monthlyInterestEarned,
        valueEndOfMonth: investmentValue,
        monthlyInvestment: monthlyInvestment,
      });
    }
  }

  const totalEarnings = investmentValue - totalInvestment;
  const result = {
    totalInvestment: totalInvestment,
    expectedReturn: totalEarnings,
    totalEarnings: investmentValue,
  };

  return result;
}


export const formatter = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
});
