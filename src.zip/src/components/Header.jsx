const Header = () => {
  return (
    <div>
      <span id="logo">
        <center>
          <img
            src="./budget-calculator-and-dollar-coins-18869.png"
            alt="calculator"
            height={"50px"}
            width={"50px"}
          />
        </center>
      </span>
      <span id="Title">
        <center>
          <h1>Investment Calculator</h1>
        </center>
      </span>
    </div>
  );
};

export default Header;
