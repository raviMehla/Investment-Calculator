const InputArea = ({ onchange, userData, userTotalValue, result }) => {
  return (
    <div id="input-area">
      <center>
        <div id="inputs">
          <label className="all-label" htmlFor="monthlyInvestment">
            Monthly Investment:
          </label>
          <input
            className="input-fields"
            type="number"
            id="monthlyInvestment"
            placeholder="Enter monthly investment"
            value={userData.monthlyInvestment}
            onChange={(event) =>
              onchange("monthlyInvestment", event.target.value)
            }
            required
          />
          <label className="all-label" htmlFor="expectedReturn">
            Expected Return:
          </label>
          <input
            className="input-fields"
            type="number"
            id="expectedReturn"
            placeholder="Enter expected return"
            value={userData.expectedReturn}
            onChange={(event) => onchange("expectedReturn", event.target.value)}
            required
          />
          <label className="all-label" htmlFor="duration">
            Time Period (in months):
          </label>
          <input
            className="input-fields"
            type="number"
            id="duration"
            placeholder="Enter time period"
            value={userData.duration}
            onChange={(event) => onchange("duration", event.target.value)}
            required
          />
        </div>
        <button
          id="Calculate-btn"
          onClick={() => result(userTotalValue(userData))}
        >
          Calculate
        </button>
      </center>
    </div>
  );
};

export default InputArea;
