const Output = ({ userData }) => {
  return (
    <center>
      <div id="output">
        <h3>Total Investment : {`Rs. ${userData.totalInvestment}`}</h3>
        <h3>Estimated Return : {`Rs. ${userData.expectedReturn}`}</h3>
        <h3>Total Return : {`Rs. ${userData.totalEarnings}`}</h3>
      </div>
    </center>
  );
};
export default Output;
